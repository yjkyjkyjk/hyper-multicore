# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Plan and decode TaskDesc-based MegaKernel per-core cycle records."""

from __future__ import annotations

__all__ = []

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
import struct
from typing import Any

from hyper_multicore.scheduler.config import (
    EVENT_INVALID_ID,
    INVALID_PROFILE_DESC_ID,
    INVALID_PROFILE_OWNER_ID,
    NUM_WORKERS_CUBE,
    NUM_WORKERS_VECTOR,
    RuntimeConfigC,
    TaskDescC,
    TaskType,
    vector_partition_task_count,
)
from hyper_multicore.diagnostics.common.graph import _scheduled_task_ids
from hyper_multicore.diagnostics.common.runtime import DiagnosticMode, PreparedDiagnosticRuntime


CUBE_SLOT_COUNT = NUM_WORKERS_CUBE
VECTOR_SLOT_COUNT = NUM_WORKERS_VECTOR
CORE_SLOT_COUNT = CUBE_SLOT_COUNT + VECTOR_SLOT_COUNT
RECORD_CAPACITY_ALIGNMENT = 16
CORE_HEADER = struct.Struct("<QIIIIII32x")
PROFILE_RECORD = struct.Struct("<QQIIII")
# Keep each slot representable by the Device ABI; allocate only the graph's actual requirement.
MAX_RECORDS_PER_CORE = ((0xFFFFFFFF - CORE_HEADER.size) // PROFILE_RECORD.size
                        // RECORD_CAPACITY_ALIGNMENT * RECORD_CAPACITY_ALIGNMENT)
MAX_CORE_STRIDE_BYTES = CORE_HEADER.size + MAX_RECORDS_PER_CORE * PROFILE_RECORD.size
MAX_PROFILE_BUFFER_BYTES = CORE_SLOT_COUNT * MAX_CORE_STRIDE_BYTES
INVALID_OWNER_ID = 0xFFFFFFFF
TASK_TYPE_DESC_BASE = 0x20000
GRAPH_STAGE_DESC_BASE = 0x30000
_SYSTEM_COUNTER_FREQUENCY_MHZ = {
    "ascend910b": 50.0,
    "ascend910c": 50.0,
    "ascend910_93": 50.0,
}

DEFAULT_STAGE_NAMES = {
    0x10000: "WaitDependency",
    0x10006: "TerminateTask",
    0x10007: "TriggerEvent",
}
TASK_TYPE_NAMES = {
    0: "Terminate",
    10: "BeginTaskGraph",
    101: "AddCustom",
    102: "SwiGLU",
    103: "MatMul",
    104: "GroupedMatMul",
    105: "ShmemPutMemSignal",
    106: "SwiGLUGrad",
    107: "MhcPost",
    108: "MhcNormCast",
    109: "MhcProjection",
    110: "MhcMapping",
    111: "RmsNorm",
    112: "MhcInputMix",
    113: "RmsNormGrad",
    114: "MhcGradPrevA",
    115: "MhcGradMapping",
    116: "MhcGradPhiRms",
    117: "MhcGradPrevXAndPost",
    118: "MhcPostGrad",
    119: "MhcGradPrevAAndMapping",
    141: "ShmemGetMem",
}
CORE_TYPE_NAMES = {
    1: "AIC",
    2: "AIV",
}


class _TaskExecutionMode(Enum):
    """Describe how Device workers execute scheduled task descriptors.

    ``EVENT_DRIVEN`` assigns a prebuilt task graph across AIC and AIV worker
    queues. Device events enforce graph dependencies, allowing independent
    Cube and Vector tasks to overlap.

    ``AIV_PIPELINE`` makes every active AIV worker execute the same ordered
    stage sequence on its own data shard without scheduler events.
    """

    EVENT_DRIVEN = "event_driven"
    AIV_PIPELINE = "aiv_pipeline"


@dataclass(frozen=True)
class _ProfileMetadata:
    """Host-only display metadata selected by a concrete MegaKernel builder."""

    kernel_name: str
    owner_label: str
    stage_names: Mapping[int, str]
    task_stage_names: Mapping[int, str]
    execution_mode: _TaskExecutionMode
    vector_worker_stride: int = 2


@dataclass(frozen=True)
class _ProfileLayout:
    """Host-computed per-worker record requirements and bounded buffer layout."""

    aic_required_records: int
    aiv_required_records: int
    aic_record_capacity: int
    aiv_record_capacity: int

    @property
    def buffer_size(self) -> int:
        """Return the ordinary Device buffer size for per-core cycle records."""
        return _profile_buffer_bytes_for_capacities(
            self.aic_record_capacity,
            self.aiv_record_capacity,
        )


@dataclass(frozen=True)
class _CycleTraceConfig:
    """Resolved hardware and display metadata used while decoding one buffer."""

    rank: int
    device_id: int | None
    cycle_frequency_mhz: float
    detailed_task_names: bool
    kernel_name: str
    owner_label: str
    stage_names: Mapping[int, str]
    soc_name: str
    task_stage_names: Mapping[int, str] | None = None


def _get_soc_name(device_id: int | None) -> str:
    """Return and validate the current Ascend SoC name through Torch NPU."""
    # Metadata construction and CPU/meta modules must not import an optional backend.
    import torch_npu  # pylint: disable=import-outside-toplevel

    get_device_name = torch_npu.npu.get_device_name
    try:
        soc_name = get_device_name(device_id)
    except TypeError:
        # Older torch_npu releases only expose the current-device form.
        soc_name = get_device_name()
    if not isinstance(soc_name, str) or not soc_name.strip():
        raise RuntimeError(f"Torch NPU returned an invalid Ascend SoC name: {soc_name!r}")
    return soc_name.strip()


def _resolve_cycle_frequency_mhz(soc_name: str) -> float:
    """Resolve the GetSystemCycle frequency for a backend-reported SoC name."""
    normalized_name = "".join(character for character in soc_name.lower() if character.isalnum() or character == "_")
    if not normalized_name.startswith("ascend"):
        normalized_name = f"ascend{normalized_name}"
    for soc_prefix, frequency_mhz in _SYSTEM_COUNTER_FREQUENCY_MHZ.items():
        if normalized_name.startswith(soc_prefix):
            return frequency_mhz
    supported_soc_names = ", ".join(sorted(_SYSTEM_COUNTER_FREQUENCY_MHZ))
    raise RuntimeError(
        f"Unsupported Ascend SoC for MegaKernel profiling: {soc_name!r}; "
        f"supported SoC prefixes: {supported_soc_names}"
    )


def _validate_runtime_config(runtime_config: RuntimeConfigC) -> None:
    if not isinstance(runtime_config, RuntimeConfigC):
        raise TypeError(f"runtime_config must be RuntimeConfigC, got {type(runtime_config).__name__}")


def _profile_buffer_bytes_for_capacities(aic_record_capacity: int, aiv_record_capacity: int) -> int:
    aic_stride = CORE_HEADER.size + aic_record_capacity * PROFILE_RECORD.size
    aiv_stride = CORE_HEADER.size + aiv_record_capacity * PROFILE_RECORD.size
    return CUBE_SLOT_COUNT * aic_stride + VECTOR_SLOT_COUNT * aiv_stride


def _round_up_record_capacity(required_records: int) -> int:
    """Round the full per-worker requirement without silently dropping records."""
    aligned_capacity = (
        (required_records + RECORD_CAPACITY_ALIGNMENT - 1) // RECORD_CAPACITY_ALIGNMENT * RECORD_CAPACITY_ALIGNMENT
    )
    _validate_record_capacity(aligned_capacity, "per-worker")
    return aligned_capacity


def _records_for_task(task_desc: TaskDescC) -> int:
    """Mirror the wait, compute, and trigger records emitted by ExecuteTaskProfiled()."""
    record_count = 1
    if task_desc.dependent_event != EVENT_INVALID_ID:
        record_count += 1
    if task_desc.task_type != TaskType.TASK_SHMEM_PUT_MEM_SIGNAL:
        record_count += 1
    return record_count


def _max_worker_record_count(
    runtime_config: RuntimeConfigC,
    task_indices: Any,
    scheduled_task_count: int,
    active_worker_count: int,
) -> int:
    """Return the largest record count assigned to one active worker."""
    if scheduled_task_count < 0 or scheduled_task_count > len(task_indices):
        raise ValueError(f"scheduled task count is outside RuntimeConfig capacity: {scheduled_task_count}")
    if scheduled_task_count == 0:
        return 0
    if active_worker_count <= 0:
        raise ValueError("RuntimeConfig.num_workers must identify at least one AIC/AIV worker")

    worker_record_counts = [0] * active_worker_count
    for schedule_index in range(scheduled_task_count):
        task_id = int(task_indices[schedule_index])
        if not 0 <= task_id < len(runtime_config.all_tasks):
            raise ValueError(f"scheduled task ID is outside RuntimeConfig capacity: {task_id}")
        worker_id = schedule_index % active_worker_count
        worker_record_counts[worker_id] += _records_for_task(runtime_config.all_tasks[task_id])
    return max(worker_record_counts)


def _calculate_aiv_pipeline_profile_layout(
    runtime_config: RuntimeConfigC,
) -> _ProfileLayout:
    """Size AIV slots for workers that each execute the complete stage sequence."""
    worker_capacity = int(runtime_config.num_workers)
    if not 0 < worker_capacity <= VECTOR_SLOT_COUNT:
        raise ValueError(
            "AIV pipeline worker capacity must be in "
            f"[1, {VECTOR_SLOT_COUNT}], got {worker_capacity}"
        )
    scheduled_task_count = int(runtime_config.task_index_num[1])
    if not 0 <= scheduled_task_count <= len(runtime_config.vector_task_indices):
        raise ValueError(f"scheduled task count is outside RuntimeConfig capacity: {scheduled_task_count}")
    required_records = 0
    for schedule_index in range(scheduled_task_count):
        task_id = int(runtime_config.vector_task_indices[schedule_index])
        if not 0 <= task_id < len(runtime_config.all_tasks):
            raise ValueError(f"scheduled task ID is outside RuntimeConfig capacity: {task_id}")
        task = runtime_config.all_tasks[task_id]
        if task.dependent_event != EVENT_INVALID_ID or task.trigger_event != EVENT_INVALID_ID:
            raise ValueError("AIV pipelines cannot contain scheduler events")
        required_records += 1
    return _ProfileLayout(
        aic_required_records=0,
        aiv_required_records=required_records,
        aic_record_capacity=0,
        aiv_record_capacity=_round_up_record_capacity(required_records),
    )


def _calculate_event_driven_profile_layout(
    runtime_config: RuntimeConfigC, vector_worker_stride: int = 2,
) -> _ProfileLayout:
    """Size AIC/AIV slots for event-driven task queues using the busiest worker."""
    num_workers = int(runtime_config.num_workers)
    if num_workers < 0 or num_workers % 2 != 0 or num_workers > VECTOR_SLOT_COUNT:
        raise ValueError(
            f"RuntimeConfig.num_workers must be an even value in [0, {VECTOR_SLOT_COUNT}], got {num_workers}"
        )
    active_worker_count = num_workers // 2
    aic_required_records = _max_worker_record_count(
        runtime_config,
        runtime_config.cube_task_indices,
        int(runtime_config.task_index_num[0]),
        active_worker_count,
    )
    aiv_required_records = _max_worker_record_count(
        runtime_config,
        runtime_config.vector_task_indices,
        int(runtime_config.task_index_num[1]),
        num_workers // vector_worker_stride,
    )
    communication_tasks = vector_partition_task_count(runtime_config)
    if communication_tasks is not None:
        vector_tasks = list(runtime_config.vector_task_indices[:runtime_config.task_index_num[1]])
        groups = (vector_tasks[:communication_tasks], vector_tasks[communication_tasks:])
        aiv_required_records = max(
            _max_worker_record_count(runtime_config, tasks, len(tasks), active_worker_count)
            for tasks in groups
        )
    return _ProfileLayout(
        aic_required_records=aic_required_records,
        aiv_required_records=aiv_required_records,
        aic_record_capacity=_round_up_record_capacity(aic_required_records),
        aiv_record_capacity=_round_up_record_capacity(aiv_required_records),
    )


def _calculate_profile_layout(
    runtime_config: RuntimeConfigC, metadata: _ProfileMetadata | None = None,
) -> _ProfileLayout:
    """Select the profile layout algorithm for the configured task execution mode."""
    _validate_runtime_config(runtime_config)
    if metadata is None:
        metadata = _ProfileMetadata("MegaKernel", "Owner", {}, {}, _TaskExecutionMode.EVENT_DRIVEN)
    if metadata.execution_mode is _TaskExecutionMode.AIV_PIPELINE:
        return _calculate_aiv_pipeline_profile_layout(runtime_config)
    if metadata.execution_mode is _TaskExecutionMode.EVENT_DRIVEN:
        return _calculate_event_driven_profile_layout(runtime_config, metadata.vector_worker_stride)
    raise ValueError(f"unsupported task execution mode: {metadata.execution_mode!r}")


def _configure_profile_layout(runtime_config: RuntimeConfigC, metadata: _ProfileMetadata) -> _ProfileLayout:
    """Calculate and serialize the bounded AIC/AIV record capacities."""
    layout = _calculate_profile_layout(runtime_config, metadata)
    runtime_config.aic_profile_record_capacity = layout.aic_record_capacity
    runtime_config.aiv_profile_record_capacity = layout.aiv_record_capacity
    return layout


def _resolve_stage_names(stage_names: Mapping[int, str] | None) -> dict[int, str]:
    """Merge validated kernel-specific names with the common runtime stages."""
    resolved_stage_names = dict(DEFAULT_STAGE_NAMES)
    if stage_names is None:
        return resolved_stage_names
    for desc_id, stage_name in stage_names.items():
        if isinstance(desc_id, bool) or not isinstance(desc_id, int):
            raise TypeError(f"stage_names keys must be integers, got {desc_id!r}")
        if not isinstance(stage_name, str) or not stage_name.strip():
            raise ValueError(f"stage_names values must be non-empty strings, got {stage_name!r}")
        resolved_stage_names[desc_id] = stage_name
    return resolved_stage_names


def _configure_trace_metadata(runtime_config: RuntimeConfigC, metadata: Any) -> _ProfileMetadata:
    """Encode trace-specific descriptor IDs in an independent profiling configuration."""
    stages = dict(DEFAULT_STAGE_NAMES)
    stages.update({GRAPH_STAGE_DESC_BASE + key: name for key, name in metadata.stage_names.items()})
    task_names = dict(metadata.task_stage_names)
    for task_id in set(range(int(runtime_config.task_num))) | _scheduled_task_ids(runtime_config):
        task = runtime_config.all_tasks[task_id]
        stage_id = metadata.task_stage_ids.get(task_id)
        if stage_id is not None:
            task.profile_desc_id = GRAPH_STAGE_DESC_BASE + stage_id
            owner = metadata.task_owner_ids.get(task_id)
            task.profile_owner_id = INVALID_PROFILE_OWNER_ID if owner is None else owner
        elif task.task_type == TaskType.TASK_TERMINATE:
            task.profile_desc_id = 0x10006
            task.profile_owner_id = INVALID_PROFILE_OWNER_ID
            task_names[task_id] = "TerminateTask"
        else:
            task.profile_desc_id = INVALID_PROFILE_DESC_ID
            task.profile_owner_id = INVALID_PROFILE_OWNER_ID
    return _ProfileMetadata(metadata.kernel_name, metadata.owner_label, stages, task_names,
                            _TaskExecutionMode.EVENT_DRIVEN)


class _PreparedProfileRuntime:
    """Own profiling-specific preparation and trace decoding for one runtime."""

    def __init__(self, runtime: PreparedDiagnosticRuntime) -> None:
        """Build only profiling-owned metadata, layout and Device configuration."""
        runtime_config = runtime.copy_host_config()
        self._metadata = _configure_trace_metadata(runtime_config, runtime.metadata)
        self._metadata = _ProfileMetadata(
            self._metadata.kernel_name, self._metadata.owner_label, self._metadata.stage_names,
            self._metadata.task_stage_names, _TaskExecutionMode(runtime.spec.execution_mode),
            runtime.spec.vector_worker_stride,
        )
        self._layout = _configure_profile_layout(runtime_config, self._metadata)
        self._rank = runtime.rank
        self._device_id = runtime.device_id
        self._host_config = runtime_config
        self._normal_tensor = runtime.normal_tensor
        self._device = getattr(runtime.normal_tensor, "device", None)
        runtime_config.diagnostic_mode = DiagnosticMode.PROFILE
        self._profile_tensor = runtime.tensor_from_config(runtime_config)

    @property
    def normal_tensor(self) -> Any:
        """Return the original normal image without modifying it."""
        return self._normal_tensor

    @property
    def profile_tensor(self) -> Any:
        """Return the independent profiling configuration."""
        return self._profile_tensor

    @property
    def buffer_size(self) -> int:
        """Return the exact ordinary Device buffer size required while profiling."""
        return self._layout.buffer_size

    @property
    def rank(self) -> int:
        """Return the distributed rank that owns this runtime."""
        return self._rank

    @property
    def device(self) -> Any:
        """Return the device used to allocate runtime-owned tensors."""
        return self._device

    @property
    def device_id(self) -> int:
        """Return the local device index that executes this runtime."""
        return self._device_id

    @property
    def kernel_name(self) -> str:
        """Return the concrete kernel display name."""
        return self._metadata.kernel_name

    @property
    def host_config(self) -> RuntimeConfigC:
        """Return an immutable Host copy retaining the graph-sized runtime arrays."""
        return self._host_config

    @property
    def task_stage_names(self) -> Mapping[int, str]:
        """Return task ID to human-facing stage-name metadata."""
        return self._metadata.task_stage_names

    @property
    def owner_label(self) -> str:
        """Return the concrete kernel's task-owner label."""
        return self._metadata.owner_label

    def parse(self, buffer: Any, *, detailed_task_names: bool) -> dict[str, Any]:
        """Decode one completed invocation buffer.

        Args:
            buffer: Host-visible bytes copied from the profiling buffer.
            detailed_task_names: Whether event names include owner and task details.
        """
        soc_name = _get_soc_name(self._device_id)
        return _parse_cycle_buffer(
            buffer,
            _CycleTraceConfig(
                rank=self._rank,
                device_id=self._device_id,
                cycle_frequency_mhz=_resolve_cycle_frequency_mhz(soc_name),
                detailed_task_names=detailed_task_names,
                kernel_name=self._metadata.kernel_name,
                owner_label=self._metadata.owner_label,
                stage_names=self._metadata.stage_names,
                soc_name=soc_name,
                task_stage_names=self._metadata.task_stage_names,
            ),
            aic_record_capacity=self._layout.aic_record_capacity,
            aiv_record_capacity=self._layout.aiv_record_capacity,
        )


def _as_bytes(buffer: Any) -> bytes:
    """Convert an array-like profile buffer to validated immutable bytes."""
    if hasattr(buffer, "tobytes"):
        raw_buffer = buffer.tobytes()
    else:
        raw_buffer = bytes(buffer)
    minimum_buffer_bytes = CORE_SLOT_COUNT * CORE_HEADER.size
    if len(raw_buffer) < minimum_buffer_bytes:
        raise ValueError(
            f"MegaKernel profile buffer is too small: expected at least {minimum_buffer_bytes} bytes, "
            f"got {len(raw_buffer)}"
        )
    return raw_buffer


def _validate_record_capacity(record_capacity: int, core_name: str) -> None:
    if record_capacity < 0:
        raise ValueError(f"{core_name} profile record capacity must be nonnegative: {record_capacity}")
    if record_capacity > MAX_RECORDS_PER_CORE:
        raise ValueError(
            f"{core_name} profile record capacity exceeds the {MAX_RECORDS_PER_CORE}-record limit: "
            f"{record_capacity}"
        )
    if record_capacity % RECORD_CAPACITY_ALIGNMENT != 0:
        raise ValueError(
            f"{core_name} profile record capacity must be a multiple of {RECORD_CAPACITY_ALIGNMENT}: "
            f"{record_capacity}"
        )


def _profile_layout_from_buffer(raw_buffer: bytes) -> tuple[int, int, int]:
    """Read AIC/AIV capacities from the first initialized header of each slot region."""
    aic_header = CORE_HEADER.unpack_from(raw_buffer, 0)
    aic_record_capacity = aic_header[5]
    _validate_record_capacity(aic_record_capacity, "AIC")
    aic_stride = CORE_HEADER.size + aic_record_capacity * PROFILE_RECORD.size
    aiv_region_offset = CUBE_SLOT_COUNT * aic_stride
    if len(raw_buffer) < aiv_region_offset + CORE_HEADER.size:
        raise ValueError(
            f"MegaKernel profile buffer is too small for the AIV header: "
            f"expected at least {aiv_region_offset + CORE_HEADER.size} bytes, got {len(raw_buffer)}"
        )
    aiv_header = CORE_HEADER.unpack_from(raw_buffer, aiv_region_offset)
    aiv_record_capacity = aiv_header[5]
    _validate_record_capacity(aiv_record_capacity, "AIV")
    required_buffer_bytes = _profile_buffer_bytes_for_capacities(
        aic_record_capacity,
        aiv_record_capacity,
    )
    if len(raw_buffer) < required_buffer_bytes:
        raise ValueError(
            f"MegaKernel profile buffer is too small for its declared capacities: "
            f"expected at least {required_buffer_bytes} bytes, got {len(raw_buffer)}"
        )
    return aic_record_capacity, aiv_record_capacity, required_buffer_bytes


def _profile_slot_layouts(aic_record_capacity: int, aiv_record_capacity: int):
    aic_stride = CORE_HEADER.size + aic_record_capacity * PROFILE_RECORD.size
    aiv_stride = CORE_HEADER.size + aiv_record_capacity * PROFILE_RECORD.size
    for block_id in range(CUBE_SLOT_COUNT):
        yield 1, block_id, block_id * aic_stride, aic_record_capacity
    aiv_region_offset = CUBE_SLOT_COUNT * aic_stride
    for block_id in range(VECTOR_SLOT_COUNT):
        yield 2, block_id, aiv_region_offset + block_id * aiv_stride, aiv_record_capacity


def _thread_id(core_type: int, block_id: int) -> int:
    return core_type * 1000 + block_id


def _event_name(
    desc_id: int,
    task_id: int,
    stage_task_index: int,
    owner_id: int,
    detailed_task_names: bool,
    owner_label: str,
    stage_names: Mapping[int, str],
    task_stage_names: Mapping[int, str],
) -> str:
    """Build a stage-only or detailed task name while retaining raw IDs in event args."""
    if desc_id in stage_names:
        stage_name = stage_names[desc_id]
    elif desc_id >= TASK_TYPE_DESC_BASE:
        task_type = desc_id - TASK_TYPE_DESC_BASE
        stage_name = f"TaskType_{TASK_TYPE_NAMES.get(task_type, task_type)}"
    else:
        stage_name = f"DescId_{desc_id}"
    task_stage_name = task_stage_names.get(task_id)
    if desc_id in (0x10000, 0x10007) and task_stage_name is not None:
        stage_name = f"{task_stage_name}_{stage_name}"
    if not detailed_task_names:
        return stage_name
    task_name = f"{stage_name}_task{stage_task_index + 1}"
    if owner_id == INVALID_OWNER_ID:
        return task_name
    return f"{owner_label}{owner_id}_{task_name}"


def _resolve_buffer_layout(
    raw_buffer: bytes,
    aic_record_capacity: int | None,
    aiv_record_capacity: int | None,
) -> tuple[int, int, int]:
    """Resolve and validate the two per-core capacities and total buffer size."""
    if aic_record_capacity is None and aiv_record_capacity is None:
        return _profile_layout_from_buffer(raw_buffer)
    if aic_record_capacity is None or aiv_record_capacity is None:
        raise ValueError("AIC and AIV profile capacities must be provided together")
    _validate_record_capacity(aic_record_capacity, "AIC")
    _validate_record_capacity(aiv_record_capacity, "AIV")
    required_buffer_bytes = _profile_buffer_bytes_for_capacities(
        aic_record_capacity,
        aiv_record_capacity,
    )
    if len(raw_buffer) < required_buffer_bytes:
        raise ValueError(
            "MegaKernel profile buffer is smaller than its Host-computed layout: "
            f"expected at least {required_buffer_bytes} bytes, got {len(raw_buffer)}"
        )
    return aic_record_capacity, aiv_record_capacity, required_buffer_bytes


def _validate_profile_slot_header(
    slot: int,
    core_type: int,
    block_id: int,
    expected_core_type: int,
    expected_block_id: int,
    header_capacity: int,
    record_capacity: int,
    record_count: int,
    reserved: int,
) -> None:
    """Validate the identity, layout, and count fields of one Device slot."""
    if core_type != expected_core_type or block_id != expected_block_id:
        raise ValueError(
            f"Profile slot identity mismatch: slot={slot}, expected=({expected_core_type}, {expected_block_id}), "
            f"got=({core_type}, {block_id})"
        )
    if header_capacity != record_capacity:
        raise ValueError(
            f"Profile slot capacity mismatch: slot={slot}, expected={record_capacity}, got={header_capacity}"
        )
    if reserved != 0:
        raise ValueError(f"Profile core header reserved field must be zero: slot={slot}, got={reserved}")
    if record_count > record_capacity:
        raise ValueError(
            f"Profile record count exceeds capacity: slot={slot}, count={record_count}, "
            f"capacity={record_capacity}"
        )


def _decode_slot_records(
    raw_buffer: bytes,
    slot: int,
    slot_offset: int,
    record_count: int,
    core_type: int,
    block_id: int,
    entry_cycle: int,
) -> list[dict[str, int]]:
    """Decode all cycle records stored after one validated core header."""
    records = []
    record_offset = slot_offset + CORE_HEADER.size
    for record_index in range(record_count):
        record = PROFILE_RECORD.unpack_from(raw_buffer, record_offset + record_index * PROFILE_RECORD.size)
        if record[1] < record[0]:
            raise ValueError(
                f"Profile cycle interval is negative: slot={slot}, record={record_index}, "
                f"start={record[0]}, end={record[1]}"
            )
        records.append(
            {
                "start_cycle": record[0],
                "end_cycle": record[1],
                "desc_id": record[2],
                "task_id": record[3],
                "stage_task_index": record[4],
                "owner_id": record[5],
                "core_type": core_type,
                "block_id": block_id,
                "entry_cycle": entry_cycle,
            }
        )
    return records


def _decode_profile_slot(
    raw_buffer: bytes,
    slot: int,
    layout: tuple[int, int, int, int],
) -> tuple[list[dict[str, int]], int | None, int]:
    """Decode one initialized slot and return records, entry cycle, and drops."""
    expected_core_type, expected_block_id, slot_offset, record_capacity = layout
    header = CORE_HEADER.unpack_from(raw_buffer, slot_offset)
    if not any(header):
        return [], None, 0
    entry_cycle, record_count, dropped_count, core_type, block_id, header_capacity, reserved = header
    _validate_profile_slot_header(
        slot,
        core_type,
        block_id,
        expected_core_type,
        expected_block_id,
        header_capacity,
        record_capacity,
        record_count,
        reserved,
    )
    if record_count == 0:
        return [], None, dropped_count
    return (
        _decode_slot_records(
            raw_buffer,
            slot,
            slot_offset,
            record_count,
            core_type,
            block_id,
            entry_cycle,
        ),
        entry_cycle or None,
        dropped_count,
    )


def _decode_cycle_records(
    raw_buffer: bytes,
    aic_record_capacity: int,
    aiv_record_capacity: int,
) -> tuple[list[dict[str, int]], list[int], int]:
    """Decode all initialized AIC/AIV slots and aggregate drop counters."""
    raw_records = []
    active_entry_cycles = []
    dropped_records = 0
    for slot, layout in enumerate(_profile_slot_layouts(aic_record_capacity, aiv_record_capacity)):
        records, entry_cycle, dropped_count = _decode_profile_slot(raw_buffer, slot, layout)
        dropped_records += dropped_count
        if entry_cycle is not None:
            active_entry_cycles.append(entry_cycle)
        raw_records.extend(records)
    return raw_records, active_entry_cycles, dropped_records


def _thread_metadata_events(
    rank: int,
    device_id: int,
    kernel_name: str,
    raw_records: list[dict[str, int]],
) -> list[dict[str, Any]]:
    """Build process and thread metadata for all cores that emitted records."""
    trace_events = [
        {
            "name": "process_name",
            "ph": "M",
            "pid": rank,
            "tid": 0,
            "args": {"name": f"{kernel_name} rank {rank} device {device_id}"},
        }
    ]
    used_threads = sorted({(record["core_type"], record["block_id"]) for record in raw_records})
    for sort_index, (core_type, block_id) in enumerate(used_threads):
        thread_id = _thread_id(core_type, block_id)
        trace_events.extend(
            [
                {
                    "name": "thread_name",
                    "ph": "M",
                    "pid": rank,
                    "tid": thread_id,
                    "args": {"name": f"{CORE_TYPE_NAMES[core_type]}/{block_id}"},
                },
                {
                    "name": "thread_sort_index",
                    "ph": "M",
                    "pid": rank,
                    "tid": thread_id,
                    "args": {"sort_index": sort_index},
                },
            ]
        )
    return trace_events


def _duration_trace_event(
    record: Mapping[str, int],
    *,
    rank: int,
    device_id: int,
    anchor_cycle: int,
    cycle_frequency_mhz: float,
    detailed_task_names: bool,
    owner_label: str,
    stage_names: Mapping[int, str],
    task_stage_names: Mapping[int, str],
) -> dict[str, Any]:
    """Convert one raw cycle record into a Chrome Trace duration event."""
    desc_id = record["desc_id"]
    task_id = record["task_id"]
    args = {
        "rank": rank,
        "device_id": device_id,
        "core_type": CORE_TYPE_NAMES[record["core_type"]],
        "block_id": record["block_id"],
        "task_id": task_id,
        "desc_id": desc_id,
        "stage_task_index": record["stage_task_index"],
        "task_number": record["stage_task_index"] + 1,
        "start_cycle": record["start_cycle"],
        "end_cycle": record["end_cycle"],
        "core_entry_cycle": record["entry_cycle"],
    }
    if task_id in task_stage_names:
        args["task_stage"] = task_stage_names[task_id]
    if desc_id >= TASK_TYPE_DESC_BASE:
        args["task_type"] = desc_id - TASK_TYPE_DESC_BASE
    if record["owner_id"] != INVALID_OWNER_ID:
        args["owner_id"] = record["owner_id"]
    return {
        "name": _event_name(
            desc_id,
            task_id,
            record["stage_task_index"],
            record["owner_id"],
            detailed_task_names,
            owner_label,
            stage_names,
            task_stage_names,
        ),
        "cat": "MegaKernelInternal",
        "ph": "X",
        "pid": rank,
        "tid": _thread_id(record["core_type"], record["block_id"]),
        "ts": (record["start_cycle"] - anchor_cycle) / cycle_frequency_mhz,
        "dur": (record["end_cycle"] - record["start_cycle"]) / cycle_frequency_mhz,
        "args": args,
    }


def _parse_cycle_buffer(
    buffer: Any,
    config: _CycleTraceConfig,
    *,
    aic_record_capacity: int | None = None,
    aiv_record_capacity: int | None = None,
) -> dict[str, Any]:
    """Decode a device cycle buffer with already resolved hardware and display metadata."""
    if config.cycle_frequency_mhz <= 0:
        raise ValueError(f"cycle_frequency_mhz must be positive, got {config.cycle_frequency_mhz}")
    resolved_stage_names = _resolve_stage_names(config.stage_names)
    resolved_task_stage_names = dict(config.task_stage_names or {})
    raw_buffer = _as_bytes(buffer)
    aic_record_capacity, aiv_record_capacity, required_buffer_bytes = _resolve_buffer_layout(
        raw_buffer,
        aic_record_capacity,
        aiv_record_capacity,
    )
    raw_records, active_entry_cycles, dropped_records = _decode_cycle_records(
        raw_buffer,
        aic_record_capacity,
        aiv_record_capacity,
    )
    if not raw_records:
        raise ValueError(
            "MegaKernel cycle profile buffer contains no records; verify that the current profiler schedule is active "
            "and that the profiled operator completed"
        )
    anchor_cycle = (
        min(active_entry_cycles) if active_entry_cycles else min(record["start_cycle"] for record in raw_records)
    )
    resolved_device_id = config.rank if config.device_id is None else config.device_id
    trace_events = _thread_metadata_events(config.rank, resolved_device_id, config.kernel_name, raw_records)
    for record in sorted(
        raw_records,
        key=lambda item: (item["start_cycle"], item["core_type"], item["block_id"]),
    ):
        trace_events.append(_duration_trace_event(
            record,
            rank=config.rank,
            device_id=resolved_device_id,
            anchor_cycle=anchor_cycle,
            cycle_frequency_mhz=config.cycle_frequency_mhz,
            detailed_task_names=config.detailed_task_names,
            owner_label=config.owner_label,
            stage_names=resolved_stage_names,
            task_stage_names=resolved_task_stage_names,
        ))
    return {
        "traceEvents": trace_events,
        "megaKernelCycleTrace": {
            "schemaVersion": 1,
            "rank": config.rank,
            "deviceId": resolved_device_id,
            "socName": config.soc_name,
            "cycleFrequencyMHz": config.cycle_frequency_mhz,
            "anchorCycle": anchor_cycle,
            "recordCapacityPerCore": {
                "AIC": aic_record_capacity,
                "AIV": aiv_record_capacity,
            },
            "maxRecordCapacityPerCore": MAX_RECORDS_PER_CORE,
            "recordCount": len(raw_records),
            "droppedRecordCount": dropped_records,
            "profileBufferBytes": required_buffer_bytes,
            "detailedTaskNames": config.detailed_task_names,
            "kernelName": config.kernel_name,
            "ownerLabel": config.owner_label,
            "warnings": ([] if dropped_records == 0 else [f"Device dropped {dropped_records} cycle trace records"]),
        },
    }
