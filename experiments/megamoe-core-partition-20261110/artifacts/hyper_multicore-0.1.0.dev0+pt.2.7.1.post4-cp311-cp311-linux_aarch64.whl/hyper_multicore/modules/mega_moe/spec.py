# Copyright 2026 Huawei Technologies Co., Ltd
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Validated shape, topology, and hardware specification for MegaMoe."""

from __future__ import annotations

import math
import os
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

import torch
import torch.distributed as dist


_COMMUNICATION_SPLIT = 128
_DEFAULT_CAPACITY_FACTOR = 1.25


@dataclass(frozen=True)
class MegaMoeSpec:
    """Shape, capacity, topology, and hardware values bound on first use."""

    local_num_tokens: int
    hidden_size: int
    intermediate_size: int
    num_experts: int
    top_k: int
    initial_capacity_factor: float | None
    receive_capacity: int
    ep_size: int
    ep_group: Any | None
    rank_id: int
    num_cube_cores: int
    dispatch_mode: str = "push"
    capacity_growth_factor: float | None = _DEFAULT_CAPACITY_FACTOR
    dispatch_split: int = _COMMUNICATION_SPLIT
    combine_split: int = _COMMUNICATION_SPLIT
    swiglu_split: int = _COMMUNICATION_SPLIT
    swiglu_limit: float | None = None
    max_local_num_tokens: int | None = None
    schedule_tokens: int | None = None
    expert_weight_layout: str = "EIO"
    auto_tokens: bool = False
    forward_fusion_mode: str = "legacy"
    backward_fusion_mode: str = "legacy"
    shared_intermediate_size: int = 0
    forward_shared_expert: bool = False
    backward_shared_expert: bool = False

    @property
    def dynamic_tokens(self) -> bool:
        """Report variable-length execution with automatic or bounded storage."""
        return self.auto_tokens or self.max_local_num_tokens is not None

    @property
    def plan_tokens(self) -> int:
        """Return schedule coverage independently of reserved source storage."""
        return self.local_num_tokens if self.schedule_tokens is None else self.schedule_tokens

    @property
    def local_experts(self) -> int:
        """Return experts owned by this expert-parallel rank."""
        return self.num_experts // self.ep_size

    @property
    def routed_slots(self) -> int:
        """Return routed rows produced by local Top-K expansion."""
        return self.local_num_tokens * self.top_k


    @property
    def forward_permute_fused(self) -> bool:
        """Return whether the forward permute endpoint runs in the MegaKernel."""
        return self.forward_fusion_mode in {"permute", "both"}

    @property
    def forward_unpermute_fused(self) -> bool:
        """Return whether the forward unpermute endpoint runs in the MegaKernel."""
        return self.forward_fusion_mode in {"unpermute", "both"}

    @property
    def backward_permute_fused(self) -> bool:
        """Return whether the backward permute endpoint runs in the MegaKernel."""
        return self.backward_fusion_mode in {"permute", "both"}

    @property
    def backward_unpermute_fused(self) -> bool:
        """Return whether the backward unpermute endpoint runs in the MegaKernel."""
        return self.backward_fusion_mode in {"unpermute", "both"}


def _resolve_fusion_modes(specification: Mapping[str, Any]) -> tuple[str, str]:
    """Resolve route endpoints before resource agreement and symmetric allocation."""
    supported = (specification["top_k"] <= 16
                 and (specification.get("auto_tokens", False)
                      or specification["local_num_tokens"] * specification["top_k"] <= 1 << 24))
    shared = os.getenv("HYPER_MULTICORE_MEGA_MOE_FUSION_MODE")
    defaults = ("legacy", "legacy")
    modes = []
    for direction, default in zip(("forward", "backward"), defaults):
        name = f"{direction}_fusion_mode"
        value = specification.get(name)
        if value is None:
            value = os.getenv(f"HYPER_MULTICORE_MEGA_MOE_{direction.upper()}_FUSION_MODE", shared or default)
        if value not in {"legacy", "permute", "unpermute", "both"}:
            raise ValueError(f"{name} must be legacy, permute, unpermute or both, got {value!r}")
        if value != "legacy" and not supported:
            raise ValueError("Route fusion requires top_k <= 16 and actual T * K <= 2**24")
        modes.append(value)
    return modes[0], modes[1]


def _resolve_shared_fusion_modes(specification: Mapping[str, Any]) -> tuple[bool, bool]:
    """Resolve independent shared-expert forward and backward switches."""
    shared_default = False
    shared = os.getenv("HYPER_MULTICORE_MEGA_MOE_SHARED_EXPERT")
    result = []
    for direction in ("forward", "backward"):
        value = specification.get(f"{direction}_shared_expert")
        if value is None:
            value = os.getenv(
                f"HYPER_MULTICORE_MEGA_MOE_{direction.upper()}_SHARED_EXPERT",
                shared if shared is not None else str(shared_default),
            )
        if isinstance(value, str):
            normalized = value.lower()
            if normalized not in {"1", "true", "yes", "on", "0", "false", "no", "off"}:
                raise ValueError(f"{direction}_shared_expert must be a boolean")
            value = normalized in {"1", "true", "yes", "on"}
        if not isinstance(value, bool):
            raise ValueError(f"{direction}_shared_expert must be a boolean")
        result.append(value)
    if not specification.get("shared_intermediate_size", 0) and any(result):
        raise ValueError("shared expert fusion requires shared_intermediate_size")
    return result[0], result[1]


def _align_capacity(capacity: int) -> int:
    """Align receive capacity to the baseline compute tile, independent of communication tiles."""
    return (
        (capacity + _COMMUNICATION_SPLIT - 1)
        // _COMMUNICATION_SPLIT
        * _COMMUNICATION_SPLIT
    )


def _resolve_receive_capacity(
    initial_capacity_factor: float | None,
    routed_slots: int,
    ep_size: int,
) -> int:
    """Resolve initial receive rows without exceeding the lossless route bound."""
    factor = 1.0 if initial_capacity_factor is None else initial_capacity_factor
    requested = math.ceil(min(factor, ep_size) * routed_slots)
    return _align_capacity(requested)


def _grow_receive_capacity(spec: MegaMoeSpec, current: int, required: int) -> tuple[int, int]:
    """Return geometric and minimum capacities without exceeding the lossless bound."""
    upper = _align_capacity(spec.ep_size * spec.routed_slots)
    if required > upper:
        raise ValueError("MegaMoe route exceeds the lossless token bound")
    requested = max(required, math.ceil(min(upper, current * spec.capacity_growth_factor)))
    return min(upper, _align_capacity(requested)), _align_capacity(required)


def _resolve_capacity_factors(
    dispatch_mode: str,
    initial_capacity_factor: float | None,
    capacity_growth_factor: float | None,
) -> tuple[float | None, float | None]:
    """Resolve push defaults and reject capacity knobs for pull before allocation."""
    if dispatch_mode not in ("push", "pull"):
        raise ValueError("dispatch_mode must be push or pull")
    if dispatch_mode == "pull":
        if initial_capacity_factor is not None or capacity_growth_factor is not None:
            raise ValueError("initial_capacity_factor and capacity_growth_factor are only supported for push")
        return None, None
    factors = {
        "initial_capacity_factor": (
            _DEFAULT_CAPACITY_FACTOR if initial_capacity_factor is None else initial_capacity_factor),
        "capacity_growth_factor": (
            _DEFAULT_CAPACITY_FACTOR if capacity_growth_factor is None else capacity_growth_factor),
    }
    for name, value in factors.items():
        valid_type = isinstance(value, (int, float)) and not isinstance(value, bool)
        try:
            valid = valid_type and math.isfinite(value) and value >= 1.0
        except OverflowError:
            valid = False
        if not valid:
            raise ValueError(f"{name} must be a finite number at least 1.0, got {value!r}")
    return float(factors["initial_capacity_factor"]), float(factors["capacity_growth_factor"])


def bind_mega_moe_spec(
    specification: Mapping[str, Any],
    tensor: torch.Tensor,
) -> MegaMoeSpec:
    """Bind hardware and process-group values to the first NPU input.

    Args:
        specification: Constructor-validated static resource specification.
        tensor: First input tensor used to resolve device-specific limits.

    Returns:
        Bound specification cached for subsequent forwards.

    Raises:
        ValueError: If the device or EP process group does not match the specification.
        TypeError: If the activation dtype is unsupported.
        RuntimeError: If the device does not report a valid Cube-core count.
    """
    device = torch.device(tensor.device)
    if device.type != "npu":
        raise ValueError(f"MegaMoeExperts requires an NPU input, got {device}.")
    if tensor.dtype != torch.bfloat16:
        raise TypeError(
            f"MegaMoeExperts supports BF16 activations, got {tensor.dtype}."
        )

    ep_group = specification["ep_group"]
    ep_size = specification["ep_size"]
    if dist.is_initialized():
        if ep_group is None and dist.get_world_size() > 1:
            raise ValueError("Pass ep_group explicitly for distributed MegaMoeExperts")
        group_size = dist.get_world_size(ep_group)
        rank_id = dist.get_rank(ep_group)
    else:
        if ep_group is not None:
            raise RuntimeError(
                "ep_group cannot be used before torch.distributed initialization."
            )
        group_size = 1
        rank_id = 0
    if group_size != ep_size:
        raise ValueError(
            f"ep_group world size ({group_size}) does not match ep_size ({ep_size})."
        )

    device_index = (
        device.index if device.index is not None else torch.npu.current_device()
    )
    device_limits = torch.npu.get_device_limit(device_index)
    num_cube_cores = device_limits.get("cube_core_num")
    if not isinstance(num_cube_cores, int) or num_cube_cores <= 0:
        raise RuntimeError(
            "torch.npu.get_device_limit() returned an invalid cube_core_num "
            f"for NPU {device_index}: {num_cube_cores!r}."
        )

    local_num_tokens = specification["local_num_tokens"]
    top_k = specification["top_k"]
    initial_capacity_factor = specification["initial_capacity_factor"]
    swiglu_limit = specification["swiglu_limit"]
    receive_capacity = _resolve_receive_capacity(
        initial_capacity_factor,
        local_num_tokens * top_k,
        ep_size,
    )
    forward_fusion_mode, backward_fusion_mode = _resolve_fusion_modes(specification)
    forward_shared_expert, backward_shared_expert = _resolve_shared_fusion_modes(specification)
    return MegaMoeSpec(
        local_num_tokens=local_num_tokens,
        hidden_size=specification["hidden_size"],
        intermediate_size=specification["intermediate_size"],
        num_experts=specification["num_experts"],
        top_k=top_k,
        initial_capacity_factor=initial_capacity_factor,
        receive_capacity=receive_capacity,
        ep_size=ep_size,
        ep_group=ep_group,
        rank_id=rank_id,
        num_cube_cores=num_cube_cores,
        swiglu_limit=swiglu_limit,
        dispatch_mode=specification.get("dispatch_mode", "push"),
        expert_weight_layout=specification.get("expert_weight_layout", "EIO"),
        capacity_growth_factor=specification.get("capacity_growth_factor", _DEFAULT_CAPACITY_FACTOR),
        dispatch_split=specification.get("dispatch_split", _COMMUNICATION_SPLIT),
        combine_split=specification.get("combine_split", _COMMUNICATION_SPLIT),
        max_local_num_tokens=specification.get("max_local_num_tokens"),
        auto_tokens=specification.get("auto_tokens", False),
        forward_fusion_mode=forward_fusion_mode, backward_fusion_mode=backward_fusion_mode,
        shared_intermediate_size=specification.get("shared_intermediate_size", 0),
        forward_shared_expert=forward_shared_expert,
        backward_shared_expert=backward_shared_expert,
    )
