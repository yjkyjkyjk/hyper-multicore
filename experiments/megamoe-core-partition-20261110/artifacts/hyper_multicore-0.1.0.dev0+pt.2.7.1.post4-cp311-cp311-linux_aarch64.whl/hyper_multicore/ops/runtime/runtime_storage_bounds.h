/*
 * Copyright 2026 Huawei Technologies Co., Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef HYPER_MULTICORE_CORE_MULTICORE_OPS_RUNTIME_RUNTIME_STORAGE_BOUNDS_H_
#define HYPER_MULTICORE_CORE_MULTICORE_OPS_RUNTIME_RUNTIME_STORAGE_BOUNDS_H_

#include <cstddef>
#include <cstdint>

namespace MulticoreRuntime {

struct RuntimeStorageBounds {
  uint64_t runtime_config_bytes;
  uint64_t event_counter_bytes;
};

// Keep the upstream native tiling at offset zero; only append launch metadata.
template <typename NativeTiling>
struct RuntimeLaunchTiling {
  NativeTiling native;
  RuntimeStorageBounds storage_bounds;
};

constexpr size_t RuntimeStorageBoundsOffset(size_t native_bytes) {
  return (native_bytes + alignof(RuntimeStorageBounds) - 1) / alignof(RuntimeStorageBounds) *
         alignof(RuntimeStorageBounds);
}

}  // namespace MulticoreRuntime

#endif  // HYPER_MULTICORE_CORE_MULTICORE_OPS_RUNTIME_RUNTIME_STORAGE_BOUNDS_H_
