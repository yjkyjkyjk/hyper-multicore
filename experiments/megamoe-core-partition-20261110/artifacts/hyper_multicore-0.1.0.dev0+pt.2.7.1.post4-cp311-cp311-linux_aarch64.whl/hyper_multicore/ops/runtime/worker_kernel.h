/**
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2026. All rights reserved.
 * This file is a part of the CANN Open Software.
 * Licensed under CANN Open Software License Agreement Version 1.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/**
 * @file worker_kernel.h
 * @brief Shared CRTP base class for AIC/AIV scheduling loop and event synchronization.
 *
 * Each op derives KernelWorker : KernelWorkerBase<KernelWorker> and supplies:
 *   - static constexpr uint32_t TILING_IDX  — index into input_list for tiling params
 *   - static constexpr uint32_t EVENT_IDX   — index into input_list for all_event_counters
 *   - void ExecuteComputeKernel(TaskDesc)    — op-specific task dispatch switch
 *   - static constexpr uint32_t DIAGNOSTIC_IDX — index into input_list for the shared profiling/dump buffer
 *
 * Compute kernels (ExecuteMatmul, ExecuteShmemPutMem, etc.) are NOT part of this class;
 * they belong in each op's worker_kernel.cpp.
 */

#ifndef HYPER_MULTICORE_CORE_MULTICORE_OPS_RUNTIME_WORKER_KERNEL_H_
#define HYPER_MULTICORE_CORE_MULTICORE_OPS_RUNTIME_WORKER_KERNEL_H_

#include "kernel_operator.h"
#include "shmem.h"
#include "runtime_config.hpp"
#include "runtime_storage_bounds.h"
#include "cycle_trace_recorder.h"
#include "l1_tensor_dump.h"

#include "get_mem.h"

using namespace AscendC;  // NOLINT(build/namespaces)

namespace MulticoreRuntime {

constexpr uint32_t VECTOR_WORKER_STRIDE = 2;
constexpr int64_t EVENT_REFRESH_TIME_UNIT_CYCLES = 50;
constexpr int64_t CUBE_EVENT_REFRESH_INTERVAL_UNITS = 50;     // 2,500 system cycles.
constexpr int64_t VECTOR_EVENT_REFRESH_INTERVAL_UNITS = 150;  // 7,500 system cycles.
// The selected SwiGLU tiling uses baseRowLen=19; smaller dynamic tails must lower it.
constexpr int64_t SWIGLU_DYNAMIC_TAIL_BASE_ROW_LIMIT = 19;
constexpr int64_t READY_SIGNAL_RADIX = 2;

// C220 has 192 KiB of UB. Route tasks own this scratch only until their MTE
// events drain; subsequent SwiGLU and SHMEM tasks can reuse the same storage.
constexpr uint64_t ROUTE_UB_BYTES = 192 * 1024;

__aicore__ inline int64_t RouteChunkElements(uint64_t scratch_begin, int64_t fallback, uint64_t element_bytes) {
  constexpr uint64_t REDUCE_RESULT_BYTES = 32;
  if (scratch_begin + fallback * element_bytes + REDUCE_RESULT_BYTES > ROUTE_UB_BYTES) {
    AscendC::Trap();
  }
  return scratch_begin + 8192 * element_bytes + REDUCE_RESULT_BYTES <= ROUTE_UB_BYTES ? 8192 : fallback;
}

template <typename T>
__aicore__ inline void AddRoundedSharedResidual(__gm__ T *source, __ubuf__ T *value_ub,
                                               LocalTensor<T> value, LocalTensor<T> output,
                                               LocalTensor<float> accumulator, LocalTensor<float> temporary,
                                               uint32_t elements) {
  // Preserve the routed BF16 rounding before the branch sum.
  AscendC::WaitFlag<AscendC::HardEvent::V_MTE2>(EVENT_ID0);
  aclshmemi_copy_gm2ub(value_ub, source, elements * sizeof(T));
  AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(EVENT_ID0);
  AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(EVENT_ID0);
  Cast(accumulator, output, RoundMode::CAST_NONE, elements);
  Cast(temporary, value, RoundMode::CAST_NONE, elements);
  PipeBarrier<PIPE_V>();
  Add(accumulator, accumulator, temporary, elements);
  PipeBarrier<PIPE_V>();
  Cast(output, accumulator, RoundMode::CAST_RINT, elements);
  PipeBarrier<PIPE_V>();
  AscendC::SetFlag<AscendC::HardEvent::V_MTE2>(EVENT_ID0);
}

enum class VectorWorkerPolicy : uint32_t {
  LEGACY_ODD = 0,
  ALL = 1,
};

enum class RuntimeStorageBoundsPolicy : uint32_t {
  NATIVE_TILING = 0,
  GRAPH_OWNED = 1,
};

template <typename Derived, VectorWorkerPolicy WorkerPolicy = VectorWorkerPolicy::LEGACY_ODD,
          RuntimeStorageBoundsPolicy StorageBoundsPolicy = RuntimeStorageBoundsPolicy::NATIVE_TILING>
class KernelWorkerBase {
 public:
  __aicore__ inline KernelWorkerBase() {}

  static constexpr uint32_t PROFILE_DESC_WAIT_DEPENDENCY = 0x10000;
  static constexpr uint32_t PROFILE_DESC_TRIGGER_EVENT = 0x10007;
  static constexpr uint32_t PROFILE_DESC_TASK_TYPE_BASE = 0x20000;

  __aicore__ inline void Init(uint32_t worker_id, __gm__ uint8_t *runtimeConfigPtr, GM_ADDR *input_list) {
    this->worker_id_ = worker_id;
    this->runtimeConfigPtr = runtimeConfigPtr;

    uint64_t runtime_bytes = 0;
    uint64_t event_bytes = 0;
    uint32_t ep_size = 1;
    uint64_t local_experts = 0;
    if constexpr (StorageBoundsPolicy == RuntimeStorageBoundsPolicy::NATIVE_TILING) {
      runtime_bytes = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 6);
      event_bytes = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 7);
      ep_size = static_cast<uint32_t>(getExtraValueFromTiling(input_list[Derived::TILING_IDX], 1));
      local_experts = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 2) / ep_size;
    } else {
      auto bounds = reinterpret_cast<__gm__ RuntimeStorageBounds *>(
        input_list[Derived::TILING_IDX] + Derived::RUNTIME_BOUNDS_OFFSET);
      runtime_bytes = bounds->runtime_config_bytes;
      event_bytes = bounds->event_counter_bytes;
    }
    if (!isRuntimeStorageValid(runtimeConfigPtr, runtime_bytes, event_bytes, ep_size, local_experts)) {
      AscendC::Trap();
    }
    this->runtime_task_capacity = getRuntimeTaskCapacity(runtimeConfigPtr);
    this->runtime_event_capacity = getRuntimeEventCapacity(runtimeConfigPtr);
#ifdef __DAV_C220_CUBE__
    // The worker's scratch region is fixed for the lifetime of this task graph.
    this->grouped_matmul_group_list_offset_ = getGroupedMatmulGroupListOffsetById(runtimeConfigPtr, worker_id);
#endif
    all_event_counters.SetGlobalBuffer((__gm__ int32_t *)(input_list[Derived::EVENT_IDX]), runtime_event_capacity);

    all_event_num_triggers.SetGlobalBuffer((__gm__ int32_t *)(runtimeConfigPtr + getAllEventNumTriggersOffset()),
                                           runtime_event_capacity);
    vector_task_indexs.SetGlobalBuffer(
      (__gm__ int32_t *)(runtimeConfigPtr + getVectorTaskIndexsOffset(runtimeConfigPtr)), runtime_task_capacity);
    cube_task_indexs.SetGlobalBuffer((__gm__ int32_t *)(runtimeConfigPtr + getCubeTaskIndexsOffset(runtimeConfigPtr)),
                                     runtime_task_capacity);
    atomic_add_values.SetGlobalBuffer((__gm__ int32_t *)(runtimeConfigPtr + getAtomicAddValuesOffset(runtimeConfigPtr)),
                                      ATOMIC_ADD_VALUE_LEN);

    this->input_list = input_list;
    this->task_num = getTaskNum(this->runtimeConfigPtr);
    this->vector_task_num = getTaskIndexNumByTaskType(this->runtimeConfigPtr, TaskAiCoreType::TASK_AICORE_VECTOR);
    this->cube_task_num = getTaskIndexNumByTaskType(this->runtimeConfigPtr, TaskAiCoreType::TASK_AICORE_CUBE);
    // RuntimeConfig is operator-independent; native tiling buffers are not.
    // Reading a fixed native-tiling offset here corrupts the round-robin stride
    // for operators whose sixth field is not the AIC count (for example mHC).
    this->vector_num = getNumWorkers(this->runtimeConfigPtr);
    this->core_num = this->vector_num / 2;
    this->active_vector_num = WorkerPolicy == VectorWorkerPolicy::ALL ? this->vector_num : this->vector_num / 2;
    this->vector_partition_ = hasVectorPartition(runtimeConfigPtr);
    if (this->vector_partition_) {
      uint32_t communication_tasks = getVectorCommunicationTaskCount(runtimeConfigPtr);
      if (communication_tasks > static_cast<uint32_t>(this->vector_task_num)) {
        AscendC::Trap();
      }
#ifndef __DAV_C220_CUBE__
      this->active_vector_num = this->core_num;
      if (this->worker_id_ % 2 == 1) {
        this->vector_task_num = communication_tasks;
      } else {
        this->vector_queue_start_ = communication_tasks;
      }
#endif
    }
  }

  __aicore__ inline void Process() {
    ReadyHandshakeMeta meta;
    bool has_ready = LoadReadyHandshakeMeta(&meta);
    pull_protocol_ = meta.completion_event != 0;
    if (has_ready) {
      WaitForDeviceReady(meta);
    }
    switch (getDiagnosticMode(this->runtimeConfigPtr)) {
      case DiagnosticMode::PROFILE:
        ProcessProfiled();
        break;
      case DiagnosticMode::TENSOR_DUMP_L1:
        ProcessL1Dump();
        break;
      default:
        ProcessFast();
    }
    if (meta.completion_event != 0) {
      CompleteDeviceReads(meta);
    }
  }

 protected:
  __aicore__ inline GM_ADDR SharedTensorAddress(const TensorDesc &desc) {
    GM_ADDR address = input_list[desc.input_position];
    if (desc.tensor_type == 2) {
      address = reinterpret_cast<GM_ADDR>(
        reinterpret_cast<__gm__ uint64_t *>(address)[desc.dynamic_dim + 1]);
    }
    return address + desc.base_ptr_offset * desc.data_type;
  }

  __aicore__ inline void ProcessFast() {
#ifdef __DAV_C220_CUBE__
    uint32_t block_idx = this->worker_id_;
    do {
      if (block_idx >= this->cube_task_num) {
        return;
      }
      TaskId task_index = GetTaskIndex(block_idx);
      ExecuteTaskFast(task_index);
      block_idx = block_idx + this->core_num;
    } while (1);
#else
    uint32_t block_idx = GetVectorScheduleIndex();
    if (block_idx == INVALID_VECTOR_SCHEDULE_INDEX) {
      return;
    }
    do {
      if (block_idx >= this->vector_task_num) {
        return;
      }
      TaskId task_index = GetTaskIndex(block_idx);
      ExecuteTaskFast(task_index);
      block_idx = block_idx + this->active_vector_num;
    } while (1);
#endif
  }

  __aicore__ inline void ProcessL1Dump() {
#ifdef __DAV_C220_CUBE__
    uint32_t block_idx = this->worker_id_;
    do {
      if (block_idx >= this->cube_task_num) {
        return;
      }
      TaskId task_index = GetTaskIndex(block_idx);
      ExecuteTaskL1Dump(task_index);
      block_idx = block_idx + this->core_num;
    } while (1);
#else
    uint32_t block_idx = GetVectorScheduleIndex();
    if (block_idx == INVALID_VECTOR_SCHEDULE_INDEX) {
      return;
    }
    do {
      if (block_idx >= this->vector_task_num) {
        return;
      }
      TaskId task_index = GetTaskIndex(block_idx);
      ExecuteTaskL1Dump(task_index);
      block_idx = block_idx + this->active_vector_num;
    } while (1);
#endif
  }

  __aicore__ inline void ProcessProfiled() {
    CycleTraceRecorder cycle_trace_recorder;
    cycle_trace_recorder.Init(this->worker_id_, this->input_list[Derived::DIAGNOSTIC_IDX],
                              getAicProfileRecordCapacity(this->runtimeConfigPtr),
                              getAivProfileRecordCapacity(this->runtimeConfigPtr));
#ifdef __DAV_C220_CUBE__
    uint32_t block_idx = this->worker_id_;
    do {
      if (block_idx >= this->cube_task_num) {
        return;
      }
      TaskId task_index = GetTaskIndex(block_idx);
      ExecuteTaskProfiled(task_index, cycle_trace_recorder);
      block_idx = block_idx + this->core_num;
    } while (1);
#else
    uint32_t block_idx = GetVectorScheduleIndex();
    if (block_idx == INVALID_VECTOR_SCHEDULE_INDEX) {
      return;
    }
    do {
      if (block_idx >= this->vector_task_num) {
        return;
      }
      TaskId task_index = GetTaskIndex(block_idx);
      ExecuteTaskProfiled(task_index, cycle_trace_recorder);
      block_idx = block_idx + this->active_vector_num;
    } while (1);
#endif
  }

  __aicore__ inline bool LoadReadyHandshakeMeta(ReadyHandshakeMeta *meta) {
    getReadyHandshakeMeta(this->runtimeConfigPtr, meta);
    return meta->ready_event != 0;
  }

  __aicore__ inline void PublishDeviceReady(const ReadyHandshakeMeta &meta, bool completion = false) {
#ifndef __DAV_C220_CUBE__
    int64_t ep = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 1);
    int64_t rank = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 0) % ep;
    constexpr uint32_t ready_stride = DATA_CACHE_LINE_SIZE / INT32_T_SIZE;
    __gm__ int32_t *ready = (__gm__ int32_t *)(input_list[Derived::EVENT_IDX]) + runtime_event_capacity;
    if (completion) {
      ready += (ep + 1) * ready_stride;
    }

    GlobalTensor<int32_t> ready_state;
    ready_state.SetGlobalBuffer(ready, static_cast<uint32_t>((ep + 1) * ready_stride));
    uint32_t generation_index = static_cast<uint32_t>(ep) * ready_stride;
    DataCacheCleanAndInvalid<int32_t, CacheLine::SINGLE_CACHE_LINE, DcciDst::CACHELINE_OUT>(
      ready_state[generation_index]);
    int32_t previous_generation = ready_state.GetValue(generation_index);
    if (previous_generation == INT32_MAX) {
      AscendC::Trap();
    }
    int32_t generation = previous_generation + 1;
    ready_state.SetValue(generation_index, generation);
    DataCacheCleanAndInvalid<int32_t, CacheLine::SINGLE_CACHE_LINE, DcciDst::CACHELINE_OUT>(
      ready_state[generation_index]);
    PipeBarrier<PIPE_ALL>();

    uint32_t round = 0;
    for (int64_t distance = 1; distance < ep; distance *= READY_SIGNAL_RADIX, ++round) {
      int64_t target = (rank + distance) % ep;
      __gm__ int32_t *round_ready = ready + round * ready_stride;
      aclshmemx_signal_op(round_ready, generation, ACLSHMEM_SIGNAL_SET, static_cast<int>(target));
      aclshmem_signal_wait_until(round_ready, ACLSHMEM_CMP_GE, generation);
    }
    if (!completion) {
      TriggerEvent(meta.ready_event);
    }
#endif
  }

  __aicore__ inline void CompleteDeviceReads(const ReadyHandshakeMeta &meta) {
#ifndef __DAV_C220_CUBE__
    if (!this->vector_partition_ && this->worker_id_ % 2 == 0) {
      return;
    }
#endif
    TriggerEvent(meta.completion_event);
#ifndef __DAV_C220_CUBE__
    if (this->worker_id_ == 1) {
      WaitForDependency(meta.completion_event);
      if (meta.ready_event != 0) {
        PublishDeviceReady(meta, true);
      }
    }
#endif
  }

  template <typename T>
  __aicore__ inline void ExecuteShmemGetMem(const TaskDesc &task) {
    int64_t ep = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 1);
    int64_t experts = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 2);
    int64_t hidden = getExtraValueFromTiling(input_list[Derived::TILING_IDX], 3);
    int64_t tiles = task.task_split_num / experts;
    int64_t source_pe = task.task_index / ((experts / ep) * tiles);
    int64_t size =
      reinterpret_cast<__gm__ int32_t *>(input_list[task.inputs[3].input_position])[task.inputs[3].base_ptr_offset];
    int64_t start = (task.task_index % tiles) * static_cast<int64_t>(task.task_split_value) * hidden;
    if (start >= size) {
#ifndef __DAV_C220_CUBE__
      if (task.extra_value_0 != 0xFFFFFFFFU && task.extra_value_2 != 0) {
        TriggerEvent(task.extra_value_2);
      }
#endif
      return;
    }
    int64_t tile_elements = static_cast<int64_t>(task.task_split_value) * hidden;
    int64_t elements = size - start < tile_elements ? size - start : tile_elements;
    int64_t destination_offset =
      reinterpret_cast<__gm__ int64_t *>(input_list[task.inputs[0].input_position])[task.inputs[0].base_ptr_offset];
    int64_t source_offset =
      reinterpret_cast<__gm__ int64_t *>(input_list[task.inputs[2].input_position])[task.inputs[2].base_ptr_offset];
#ifndef __DAV_C220_CUBE__
    if (task.extra_value_0 != 0xFFFFFFFFU) {
      ExecuteIndexedPull<T>(task, source_pe, source_offset + start, destination_offset + start, elements, hidden);
      if (task.extra_value_2 != 0) {
        TriggerEvent(task.extra_value_2);
      }
      return;
    }
#endif
    PullToLocal<T>(input_list[task.outputs[0].input_position] + (destination_offset + start) * sizeof(T),
                   input_list[task.inputs[1].input_position] + (source_offset + start) * sizeof(T), elements,
                   source_pe);
  }

#ifndef __DAV_C220_CUBE__
  template <typename T>
  __aicore__ inline LocalTensor<T> RouteLocalTensor(uint64_t address, uint32_t elements) {
    LocalTensor<T> result;
    TBuffAddr buffer{};
    buffer.logicPos = static_cast<uint8_t>(TPosition::VECCALC);
    buffer.bufferAddr = address;
#if ASCENDC_CPU_DEBUG
    buffer.dataLen = elements * sizeof(T);
    buffer.absAddr = reinterpret_cast<uint8_t *>(address);
#endif
    result.SetAddr(buffer);
    result.SetSize(elements);
    return result;
  }

  template <typename T>
  __aicore__ inline void PullIndexedRows(__gm__ T *source, __gm__ T *destination, __ubuf__ int32_t *metadata,
                                         uint64_t scratch, int64_t rows, int64_t hidden, uint32_t top_k,
                                         bool weighted) {
    constexpr int64_t CHUNK = 8192;
    uint64_t value_bytes = CHUNK * sizeof(T);
    if (scratch + 2 * value_bytes + CHUNK * sizeof(float) > ROUTE_UB_BYTES) {
      AscendC::Trap();
    }
    LocalTensor<T> ping = RouteLocalTensor<T>(scratch, CHUNK);
    LocalTensor<T> pong = RouteLocalTensor<T>(scratch + value_bytes, CHUNK);
    LocalTensor<float> temporary = RouteLocalTensor<float>(scratch + 2 * value_bytes, CHUNK);
    auto *weights = reinterpret_cast<__ubuf__ float *>(metadata);
    __ubuf__ T *buffers[2] = {reinterpret_cast<__ubuf__ T *>(scratch),
                            reinterpret_cast<__ubuf__ T *>(scratch + value_bytes)};
    for (int64_t col = 0; col < hidden; col += CHUNK) {
      int64_t elements = hidden - col < CHUNK ? hidden - col : CHUNK;
      uint64_t bytes = elements * sizeof(T);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(EVENT_ID0);
      AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(EVENT_ID1);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(EVENT_ID0);
      int64_t first = metadata[0] / top_k;
      aclshmemi_copy_gm2ub(buffers[0], source + first * hidden + col, bytes);
      AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(EVENT_ID0);
      for (int64_t row = 0; row < rows; ++row) {
        uint32_t parity = row & 1;
        AscendC::TEventID event = parity ? EVENT_ID1 : EVENT_ID0;
        LocalTensor<T> value = parity ? pong : ping;
        AscendC::WaitFlag<AscendC::HardEvent::MTE2_V>(event);
        if (row + 1 < rows) {
          AscendC::TEventID next = parity ? EVENT_ID0 : EVENT_ID1;
          AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(next);
          int64_t token = metadata[(row + 1) * 2] / top_k;
          aclshmemi_copy_gm2ub(buffers[1 - parity], source + token * hidden + col, bytes);
          AscendC::SetFlag<AscendC::HardEvent::MTE2_V>(next);
        }
        if (weighted) {
          float weight = weights[row * 2 + 1];
          Cast(temporary, value, RoundMode::CAST_NONE, elements);
          PipeBarrier<PIPE_V>();
          Muls(temporary, temporary, weight, elements);
          PipeBarrier<PIPE_V>();
          Cast(value, temporary, RoundMode::CAST_RINT, elements);
        }
        AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(event);
        AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(event);
        aclshmemi_copy_ub2gm(destination + row * hidden + col, buffers[parity], bytes);
        AscendC::SetFlag<AscendC::HardEvent::MTE3_MTE2>(event);
      }
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(EVENT_ID0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE3_MTE2>(EVENT_ID1);
    }
  }

  template <typename T>
  __aicore__ inline void ExecuteIndexedPull(const TaskDesc &task, int source_pe, int64_t source_offset,
                                            int64_t destination_offset, int64_t elements, int64_t hidden) {
    namespace plane = hyper_multicore::shmem::data_plane;
    constexpr int64_t META_ROWS = 128;
    // Each task drains all transfers before another task reuses this worker's UB.
    uint64_t scratch_ub;
    uint64_t transport_bytes;
    if (!hyper_multicore::shmem::cann::device::query_mte_resources(
          source_pe, scratch_ub, transport_bytes) || transport_bytes == 0) {
      AscendC::Trap();
    }
    auto *remote_data = reinterpret_cast<__gm__ T *>(plane::remote_ptr(
      input_list[task.inputs[1].input_position], source_pe));
    auto *remote_metadata = reinterpret_cast<__gm__ int32_t *>(plane::remote_ptr(
      input_list[task.extra_value_0], source_pe));
    if (remote_data == nullptr || remote_metadata == nullptr) {
      AscendC::Trap();
    }
    auto *destination = reinterpret_cast<__gm__ T *>(input_list[task.outputs[0].input_position]) + destination_offset;
    int64_t source_row = source_offset / hidden;
    int64_t total_rows = elements / hidden;
    for (int64_t begin = 0; begin < total_rows; begin += META_ROWS) {
      int64_t rows = total_rows - begin < META_ROWS ? total_rows - begin : META_ROWS;
      auto *metadata = reinterpret_cast<__ubuf__ int32_t *>(scratch_ub);
      aclshmemi_copy_gm2ub(metadata, remote_metadata + (source_row + begin) * 2,
                           rows * 2 * sizeof(int32_t));
      // No TPipe is alive in the transport task. Own a fixed event rather
      // than querying FetchEventID through the previous task's pipe pointer.
      AscendC::SetFlag<AscendC::HardEvent::MTE2_S>(EVENT_ID0);
      AscendC::WaitFlag<AscendC::HardEvent::MTE2_S>(EVENT_ID0);
      PullIndexedRows<T>(remote_data, destination + begin * hidden, metadata,
                         scratch_ub + META_ROWS * 2 * sizeof(int32_t), rows, hidden,
                         task.inputs[1].dim[3], task.extra_value_1 != 0xFFFFFFFFU);
    }
  }
#endif

  __aicore__ inline void WaitForDeviceReady(const ReadyHandshakeMeta &meta) {
#ifdef __DAV_C220_CUBE__
    WaitForDependency(meta.ready_event);
#else
    if (!this->vector_partition_ && this->worker_id_ % VECTOR_WORKER_STRIDE == 0) {
      return;
    }
    if (this->worker_id_ == 1) {
      PublishDeviceReady(meta);
    }
    WaitForDependency(meta.ready_event);
#endif
  }

  __aicore__ inline TaskId GetTaskIndex(uint32_t task_id) {
#ifdef __DAV_C220_CUBE__
    return cube_task_indexs.GetValue(task_id);
#else
    return vector_task_indexs.GetValue(task_id);
#endif
  }

  __aicore__ inline uint32_t GetVectorScheduleIndex() {
    if (this->vector_partition_) {
      return this->worker_id_ < this->vector_num
               ? this->vector_queue_start_ + this->worker_id_ / 2
               : INVALID_VECTOR_SCHEDULE_INDEX;
    }
    if constexpr (WorkerPolicy == VectorWorkerPolicy::ALL) {
      return this->worker_id_ < this->active_vector_num ? this->worker_id_ : INVALID_VECTOR_SCHEDULE_INDEX;
    }
    return this->worker_id_ % 2 == 0 ? INVALID_VECTOR_SCHEDULE_INDEX : this->worker_id_ / 2;
  }

  __aicore__ inline void AtomicAddForAllEventCounters(uint32_t event_index) {
    TPipe eventPipe;
#ifdef __DAV_C220_CUBE__
    TBuf<AscendC::TPosition::A1> eventBuffer;
#else
    TBuf<AscendC::TPosition::VECOUT> eventBuffer;
#endif
    eventPipe.InitBuffer(eventBuffer, DISPATCH_TOKEN_UB_SIZE);
    LocalTensor<int32_t> localSet = eventBuffer.GetWithOffset<int32_t>(EXP_TOKEN_COUNT_FLAG_CNT, 0);
#ifdef __DAV_C220_CUBE__
    SyncFunc<AscendC::HardEvent::S_MTE2>();
    DataCopy(localSet, this->atomic_add_values, EXP_TOKEN_COUNT_FLAG_CNT);
    SyncFunc<AscendC::HardEvent::MTE2_S>();
    AscendC::SetAtomicAdd<int32_t>();
    SyncFunc<AscendC::HardEvent::S_MTE2>();
    DataCopy(this->all_event_counters[event_index], localSet, EXP_TOKEN_COUNT_FLAG_CNT);
    SyncFunc<AscendC::HardEvent::MTE2_S>();
    AscendC::SetAtomicNone();
#else
    localSet.SetValue(0, 1);
    for (int32_t i = 1; i < EXP_TOKEN_COUNT_FLAG_CNT; ++i) {
      localSet.SetValue(i, 0);
    }
    AscendC::SetAtomicAdd<int32_t>();
    SyncFunc<AscendC::HardEvent::S_MTE3>();
    DataCopy(this->all_event_counters[event_index], localSet, EXP_TOKEN_COUNT_FLAG_CNT);
    SyncFunc<AscendC::HardEvent::MTE3_S>();
    AscendC::SetAtomicNone();
#endif
    eventBuffer.FreeTensor(localSet);
    eventPipe.Destroy();
  }

  __aicore__ inline void ExecuteTaskFast(TaskId task_id) {
    if (task_id >= runtime_task_capacity) {
      AscendC::Trap();
    }
    TaskDesc task_desc;
    getTaskDesc(this->runtimeConfigPtr, &(task_desc), task_id);
    if ((task_desc.dependent_event != EVENT_INVALID_ID && task_desc.dependent_event >= runtime_event_capacity) ||
        static_cast<uint64_t>(task_desc.trigger_event) + ATOMIC_ADD_VALUE_LEN > runtime_event_capacity) {
      AscendC::Trap();
    }
    if (task_desc.dependent_event != EVENT_INVALID_ID) {
      WaitForDependency(task_desc.dependent_event,
                        (task_desc.task_type == TaskType::TASK_SHMEM_PUT_MEM_SIGNAL ||
                         task_desc.task_type == TaskType::TASK_SHMEM_GET_MEM) ? 0 : task_desc.extra_value_2);
    }
    static_cast<Derived *>(this)->ExecuteComputeKernel(task_desc);
    if (task_desc.task_type != TaskType::TASK_SHMEM_PUT_MEM_SIGNAL) {
      TriggerEvent(task_desc.trigger_event);
    }
  }

  __aicore__ inline void ExecuteTaskL1Dump(TaskId task_id) {
    if (task_id >= runtime_task_capacity) {
      AscendC::Trap();
    }
    TaskDesc task_desc;
    getTaskDesc(this->runtimeConfigPtr, &(task_desc), task_id);
    if ((task_desc.dependent_event != EVENT_INVALID_ID && task_desc.dependent_event >= runtime_event_capacity) ||
        static_cast<uint64_t>(task_desc.trigger_event) + ATOMIC_ADD_VALUE_LEN > runtime_event_capacity) {
      AscendC::Trap();
    }
    if (task_desc.dependent_event != EVENT_INVALID_ID) {
      WaitForDependency(task_desc.dependent_event,
                        (task_desc.task_type == TaskType::TASK_SHMEM_PUT_MEM_SIGNAL ||
                         task_desc.task_type == TaskType::TASK_SHMEM_GET_MEM) ? 0 : task_desc.extra_value_2);
    }
    static_cast<Derived *>(this)->CaptureL1TaskTensors(task_id, L1_DUMP_PHASE_BEFORE);
    static_cast<Derived *>(this)->ExecuteComputeKernel(task_desc);
    PipeBarrier<PIPE_ALL>();
    static_cast<Derived *>(this)->CaptureL1TaskTensors(task_id, L1_DUMP_PHASE_AFTER);
    if (task_desc.task_type != TaskType::TASK_SHMEM_PUT_MEM_SIGNAL) {
      TriggerEvent(task_desc.trigger_event);
    }
  }

  __aicore__ inline void CaptureL1TaskTensors(TaskId task_id, uint32_t phase) {
    MulticoreRuntime::CaptureL1TaskTensors(input_list[Derived::DIAGNOSTIC_IDX], input_list, task_id, phase, worker_id_);
  }

  __aicore__ inline void ExecuteTaskProfiled(TaskId task_id, CycleTraceRecorder &cycle_trace_recorder) {
    if (task_id >= runtime_task_capacity) {
      AscendC::Trap();
    }
    TaskDesc task_desc;
    getTaskDesc(this->runtimeConfigPtr, &(task_desc), task_id);
    if ((task_desc.dependent_event != EVENT_INVALID_ID && task_desc.dependent_event >= runtime_event_capacity) ||
        static_cast<uint64_t>(task_desc.trigger_event) + ATOMIC_ADD_VALUE_LEN > runtime_event_capacity) {
      AscendC::Trap();
    }
    uint32_t owner_id = getTaskProfileOwnerId(this->runtimeConfigPtr, task_id);
    if (task_desc.dependent_event != EVENT_INVALID_ID) {
      uint64_t wait_start_cycle = cycle_trace_recorder.Now();
      WaitForDependency(task_desc.dependent_event,
                        (task_desc.task_type == TaskType::TASK_SHMEM_PUT_MEM_SIGNAL ||
                         task_desc.task_type == TaskType::TASK_SHMEM_GET_MEM) ? 0 : task_desc.extra_value_2);
      uint64_t wait_end_cycle = cycle_trace_recorder.Now();
      cycle_trace_recorder.Record(Derived::PROFILE_DESC_WAIT_DEPENDENCY, task_id, task_desc.task_index, owner_id,
                                  wait_start_cycle, wait_end_cycle);
    }
    uint32_t profile_desc_id = getTaskProfileDescId(this->runtimeConfigPtr, task_id);
    if (profile_desc_id == PROFILE_DESC_INVALID_ID) {
      profile_desc_id = PROFILE_DESC_TASK_TYPE_BASE + static_cast<uint32_t>(task_desc.task_type);
    }
    uint64_t compute_start_cycle = cycle_trace_recorder.Now();
    static_cast<Derived *>(this)->ExecuteComputeKernel(task_desc);
    uint64_t compute_end_cycle = cycle_trace_recorder.Now();
    cycle_trace_recorder.Record(profile_desc_id, task_id, task_desc.task_index, owner_id, compute_start_cycle,
                                compute_end_cycle);
    if (task_desc.task_type != TaskType::TASK_SHMEM_PUT_MEM_SIGNAL) {
      uint64_t trigger_start_cycle = cycle_trace_recorder.Now();
      TriggerEvent(task_desc.trigger_event);
      uint64_t trigger_end_cycle = cycle_trace_recorder.Now();
      cycle_trace_recorder.Record(Derived::PROFILE_DESC_TRIGGER_EVENT, task_id, task_desc.task_index, owner_id,
                                  trigger_start_cycle, trigger_end_cycle);
    }
  }

  __aicore__ inline void WaitForDependency(uint32_t event_index, uint32_t poll_interval_us = 0) {
    // Pull producers signal locally after MTE3 completion. Observe short-lived
    // GMM/SwiGLU dependencies promptly while retaining a bounded refresh rate.
#ifdef __DAV_C220_CUBE__
    const uint32_t default_poll_interval_us = pull_protocol_ ? 10 : CUBE_EVENT_REFRESH_INTERVAL_UNITS;
#else
    const uint32_t default_poll_interval_us = pull_protocol_ ? 30 : VECTOR_EVENT_REFRESH_INTERVAL_UNITS;
#endif
    if (poll_interval_us == 0) {
      poll_interval_us = default_poll_interval_us;
    }
    constexpr int64_t cycles_per_us = EVENT_REFRESH_TIME_UNIT_CYCLES;
    int32_t needed = all_event_num_triggers.GetValue(event_index);
    DataCacheCleanAndInvalid<int32_t, CacheLine::SINGLE_CACHE_LINE, DcciDst::CACHELINE_OUT>(
      all_event_counters[event_index]);
    int32_t current = all_event_counters.GetValue(event_index);
    PipeBarrier<PIPE_ALL>();
    int64_t previous_cycle = AscendC::GetSystemCycle();
    while (current < needed) {
      int64_t elapsed_cycles = AscendC::GetSystemCycle() - previous_cycle;
      if (elapsed_cycles / cycles_per_us > poll_interval_us) {
        DataCacheCleanAndInvalid<int32_t, CacheLine::SINGLE_CACHE_LINE, DcciDst::CACHELINE_OUT>(
          all_event_counters[event_index]);
        current = all_event_counters.GetValue(event_index);
        previous_cycle = AscendC::GetSystemCycle();
      }
    }
  }

  __aicore__ inline void TriggerEvent(uint32_t event_index) { AtomicAddForAllEventCounters(event_index); }

  bool pull_protocol_ = false;
  bool vector_partition_ = false;
  uint32_t vector_queue_start_ = 0;
  uint32_t worker_id_ = 0;
  uint32_t grouped_matmul_group_list_offset_ = 0;
  uint32_t task_num = 0;
  uint32_t runtime_task_capacity = 0;
  uint32_t runtime_event_capacity = 0;
  int32_t vector_task_num = 0;
  int32_t cube_task_num = 0;

  GlobalTensor<int32_t> all_event_counters;
  GlobalTensor<int32_t> all_event_num_triggers;
  GlobalTensor<int32_t> atomic_add_values;
  GlobalTensor<int32_t> vector_task_indexs;
  GlobalTensor<int32_t> cube_task_indexs;

  __gm__ uint8_t *runtimeConfigPtr;
  GM_ADDR *input_list = nullptr;
  int64_t core_num = 0;
  int64_t vector_num = 0;
  uint32_t active_vector_num = 0;
  static constexpr uint32_t INVALID_VECTOR_SCHEDULE_INDEX = 0xFFFFFFFF;
};

}  // namespace MulticoreRuntime

#endif  // HYPER_MULTICORE_CORE_MULTICORE_OPS_RUNTIME_WORKER_KERNEL_H_
