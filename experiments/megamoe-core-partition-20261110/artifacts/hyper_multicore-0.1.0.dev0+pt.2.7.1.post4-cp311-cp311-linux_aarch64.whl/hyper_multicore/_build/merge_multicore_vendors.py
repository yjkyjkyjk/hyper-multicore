# Copyright 2026 Huawei Technologies Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Merge isolated per-SoC multicore vendors while retaining one host payload."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
from typing import Any


_VENDOR_NAME = "hyper_multicore_nn"
_KERNEL_ROOT = Path("op_impl/ai_core/tbe/kernel")
_KERNEL_CONFIG_ROOT = _KERNEL_ROOT / "config"
_CONFIG_ROOT = Path("op_impl/ai_core/tbe/config")
_SUPPORTED_OPS_PATH = Path("framework/tensorflow/npu_supported_ops.json")
_SOC_NAME_PATTERN = re.compile(r"^ascend[0-9a-z_]+$")
_HOST_ELF_PATHS = {
    "op_api/lib/libcust_opapi.so",
    "op_impl/ai_core/tbe/op_tiling/liboptiling.so",
    "op_impl/ai_core/tbe/op_tiling/lib/linux/aarch64/libcust_opmaster_rt2.0.so",
    "op_impl/ai_core/tbe/op_tiling/lib/linux/x86_64/libcust_opmaster_rt2.0.so",
    "op_proto/lib/linux/aarch64/libcust_opsproto_rt2.0.so",
    "op_proto/lib/linux/x86_64/libcust_opsproto_rt2.0.so",
}
_HOST_IDENTITY_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_HOST_SOC_PRIORITY = {
    "ascend910_93": 0,
    "ascend910b": 1,
}


@dataclass(frozen=True)
class _MergeContext:
    """Validated paths and provenance shared by all merge phases."""

    inputs: list[tuple[str, Path]]
    output: Path
    base_soc: str
    base_vendor: Path
    base_common_files: dict[str, str]
    host_input_identity: str


def _parse_args() -> argparse.Namespace:
    """Parse explicit per-SoC vendor inputs."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        action="append",
        required=True,
        metavar="SOC=VENDOR_ROOT",
        help="Repeat once per isolated SoC build.",
    )
    parser.add_argument(
        "--host-input-identity",
        action="append",
        required=True,
        metavar="SOC=SHA256",
        help="Repeat once per input to prove an identical common host build input.",
    )
    parser.add_argument("--output", required=True)
    return parser.parse_args()


def _sha256(path: Path) -> str:
    """Return a streaming SHA256 digest."""
    digest = hashlib.sha256()
    with path.open("rb") as source_file:
        for chunk in iter(lambda: source_file.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_soc_payload(relative_path: Path, soc: str) -> bool:
    """Return whether a file belongs to the selected compiled-kernel subtree."""
    try:
        kernel_relative = relative_path.relative_to(_KERNEL_ROOT)
    except ValueError:
        kernel_relative = None
    if kernel_relative is not None and kernel_relative.parts:
        return kernel_relative.parts[0] == soc or (
            len(kernel_relative.parts) > 1
            and kernel_relative.parts[0] == "config"
            and kernel_relative.parts[1] == soc
        )
    try:
        config_relative = relative_path.relative_to(_CONFIG_ROOT)
    except ValueError:
        return False
    return bool(config_relative.parts) and config_relative.parts[0] == soc


def _common_files(vendor_root: Path, soc: str) -> dict[str, str]:
    """Hash all host/source payload that must be byte-identical across SoC builds."""
    common_files = {}
    for path in sorted(vendor_root.rglob("*")):
        if not path.is_file():
            continue
        relative_path = path.relative_to(vendor_root)
        if _is_soc_payload(relative_path, soc) or relative_path == _SUPPORTED_OPS_PATH:
            continue
        common_files[str(relative_path)] = _sha256(path)
    return common_files


def _readelf(path: Path, *arguments: str) -> str:
    """Return one readelf inspection, rejecting malformed host libraries."""
    readelf = shutil.which("readelf")
    if readelf is None:
        raise ValueError("Cannot inspect host ELF because readelf is unavailable.")
    result = subprocess.run(
        [readelf, *arguments, str(path)],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0:
        raise ValueError(f"Cannot inspect host ELF {path}: {result.stderr.strip()}")
    return result.stdout


def _host_elf_abi_fingerprint(path: Path) -> dict[str, list[str]]:
    """Describe the host ELF ABI without depending on link layout."""
    dynamic_entries = sorted(
        line.strip()
        for line in _readelf(path, "-dW").splitlines()
        if "(NEEDED)" in line or "(SONAME)" in line
    )
    dynamic_symbols: list[str] = []
    symbol_pattern = re.compile(
        r"^\s*\d+:\s+[0-9a-fA-F]+\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+\S+(?:\s+(.*))?$"
    )
    for line in _readelf(path, "--dyn-syms", "-W").splitlines():
        match = symbol_pattern.match(line)
        if not match:
            continue
        size, symbol_type, bind, visibility, name = match.groups()
        dynamic_symbols.append(" ".join((size, symbol_type, bind, visibility, name or "")))
    if not dynamic_symbols:
        raise ValueError(f"Incomplete host ELF ABI fingerprint for {path}")
    return {
        "dynamic_entries": dynamic_entries,
        "dynamic_symbols": sorted(dynamic_symbols),
    }


def _host_elf_abi_mismatches(
    relative_path: str,
    base_fingerprints: dict[str, dict[str, list[str]]],
    candidate_file: Path,
) -> list[str]:
    """Return mismatched ABI fields for one known, discarded host ELF variant."""
    if relative_path not in _HOST_ELF_PATHS:
        return ["unsupported_path"]
    try:
        base_fingerprint = base_fingerprints[relative_path]
        candidate_fingerprint = _host_elf_abi_fingerprint(candidate_file)
    except ValueError as error:
        return [f"inspection_error={error}"]
    return sorted(
        field
        for field in set(base_fingerprint) | set(candidate_fingerprint)
        if base_fingerprint.get(field) != candidate_fingerprint.get(field)
    )


def _soc_payload_paths(vendor_root: Path, soc: str) -> tuple[Path, Path, Path]:
    """Return the required payload paths for one SoC."""
    kernel_path = vendor_root / _KERNEL_ROOT / soc
    kernel_config_path = vendor_root / _KERNEL_CONFIG_ROOT / soc
    config_path = vendor_root / _CONFIG_ROOT / soc
    return kernel_path, kernel_config_path, config_path


def _validate_soc_payload(vendor_root: Path, soc: str) -> None:
    """Require kernel binaries, binary indexes, and package config for one SoC."""
    for path in _soc_payload_paths(vendor_root, soc):
        if not path.is_dir() or not any(child.is_file() for child in path.rglob("*")):
            raise ValueError(f"Missing compiled {soc} vendor payload: {path}")


def _require_soc_payload(vendor_root: Path, soc: str) -> tuple[Path, Path, Path]:
    """Validate and return all required payload paths for one SoC."""
    _validate_soc_payload(vendor_root, soc)
    return _soc_payload_paths(vendor_root, soc)


def _compare_host_payload(
    base_common_files: dict[str, str],
    base_host_fingerprints: dict[str, dict[str, list[str]]],
    soc: str,
    vendor_root: Path,
) -> list[str]:
    """Validate one discarded host variant and return its ABI-compatible ELF paths."""
    common_files = _common_files(vendor_root, soc)
    if common_files == base_common_files:
        return []

    missing = sorted(set(base_common_files) - set(common_files))
    extra = sorted(set(common_files) - set(base_common_files))
    changed_candidates = sorted(
        path
        for path in set(base_common_files) & set(common_files)
        if base_common_files[path] != common_files[path]
    )
    discarded_host_variants: list[str] = []
    changed = []
    for relative_path in changed_candidates:
        mismatches = _host_elf_abi_mismatches(
            relative_path,
            base_host_fingerprints,
            vendor_root / relative_path,
        )
        if not mismatches:
            discarded_host_variants.append(f"{soc}:{relative_path}")
        else:
            changed.append(f"{relative_path}[{','.join(mismatches)}]")
    if missing or extra or changed:
        raise ValueError(
            f"Per-SoC host vendor payload differs for {soc}: "
            f"missing={missing}, extra={extra}, changed={changed}"
        )
    return discarded_host_variants


def _normalize_inputs(inputs: list[tuple[str, Path]]) -> tuple[list[tuple[str, Path]], set[str]]:
    """Validate per-SoC inputs and return them in canonical host priority order."""
    if not inputs:
        raise ValueError("At least one per-SoC vendor input is required.")
    normalized_inputs: list[tuple[str, Path]] = []
    seen_socs: set[str] = set()
    for soc, vendor_root in inputs:
        if not _SOC_NAME_PATTERN.fullmatch(soc) or Path(soc).name != soc:
            raise ValueError(f"Invalid SoC name: {soc!r}")
        vendor_root = vendor_root.resolve()
        if soc in seen_socs:
            raise ValueError(f"Duplicate SoC vendor input: {soc}")
        if vendor_root.name != _VENDOR_NAME or not vendor_root.is_dir():
            raise ValueError(f"Expected input vendor root named {_VENDOR_NAME}: {vendor_root}")
        _validate_soc_payload(vendor_root, soc)
        normalized_inputs.append((soc, vendor_root))
        seen_socs.add(soc)
    normalized_inputs.sort(
        key=lambda item: (_HOST_SOC_PRIORITY.get(item[0], len(_HOST_SOC_PRIORITY)), item[0])
    )
    return normalized_inputs, seen_socs


def _validate_host_input_identities(
    host_input_identities: dict[str, str],
    seen_socs: set[str],
) -> str:
    """Require one identical, well-formed common-host identity per SoC."""
    if set(host_input_identities) != seen_socs:
        raise ValueError(
            "Host input identities must match the SoC inputs exactly: "
            f"inputs={sorted(seen_socs)}, identities={sorted(host_input_identities)}"
        )
    invalid_identities = sorted(
        f"{soc}={identity}"
        for soc, identity in host_input_identities.items()
        if not _HOST_IDENTITY_PATTERN.fullmatch(identity)
    )
    if invalid_identities:
        raise ValueError(f"Invalid host input identities: {invalid_identities}")
    unique_host_input_identities = set(host_input_identities.values())
    if len(unique_host_input_identities) != 1:
        raise ValueError(f"Per-SoC common host input identities differ: {host_input_identities}")
    return next(iter(unique_host_input_identities))


def _validate_output(output: Path, normalized_inputs: list[tuple[str, Path]]) -> Path:
    """Resolve a narrow output root and reject overlap with any input."""
    output = output.resolve()
    if output.name != _VENDOR_NAME or output in {Path("/"), output.parent}:
        raise ValueError(f"Expected a narrow output vendor root named {_VENDOR_NAME}: {output}")
    for _, vendor_root in normalized_inputs:
        if (
            output == vendor_root
            or output.is_relative_to(vendor_root)
            or vendor_root.is_relative_to(output)
        ):
            raise ValueError(
                f"Output vendor must not overlap an input vendor: output={output}, input={vendor_root}"
            )
    return output


def _merge_supported_ops(
    normalized_inputs: list[tuple[str, Path]],
    output: Path,
) -> int:
    """Merge the SoC-derived supported-op keys emitted by the CANN package macros."""
    merged: dict[str, Any] = {}
    for soc, vendor_root in normalized_inputs:
        supported_ops_path = vendor_root / _SUPPORTED_OPS_PATH
        try:
            supported_ops = json.loads(supported_ops_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise ValueError(f"Cannot read {soc} supported-op metadata: {supported_ops_path}") from error
        if not isinstance(supported_ops, dict):
            raise ValueError(f"Expected an object in supported-op metadata: {supported_ops_path}")
        for key, value in supported_ops.items():
            if key in merged and merged[key] != value:
                raise ValueError(f"Conflicting supported-op metadata for key {key!r} in {soc}")
            merged[key] = value
    output_path = output / _SUPPORTED_OPS_PATH
    output_path.write_text(json.dumps(merged, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return len(merged)


def _prepare_merge(
    inputs: list[tuple[str, Path]],
    output: Path,
    host_input_identities: dict[str, str],
) -> _MergeContext:
    """Normalize inputs and select the canonical common-host vendor."""
    normalized_inputs, seen_socs = _normalize_inputs(inputs)
    host_input_identity = _validate_host_input_identities(host_input_identities, seen_socs)
    validated_output = _validate_output(output, normalized_inputs)
    base_soc, base_vendor = normalized_inputs[0]
    return _MergeContext(
        inputs=normalized_inputs,
        output=validated_output,
        base_soc=base_soc,
        base_vendor=base_vendor,
        base_common_files=_common_files(base_vendor, base_soc),
        host_input_identity=host_input_identity,
    )


def _validate_common_host_payload(context: _MergeContext) -> list[str]:
    """Validate the retained host payload and all discarded variants."""
    base_host_libraries = sorted(set(context.base_common_files) & _HOST_ELF_PATHS)
    if not base_host_libraries:
        raise ValueError(f"Base vendor contains no recognized host ELF: {context.base_vendor}")
    base_host_fingerprints = {
        relative_path: _host_elf_abi_fingerprint(context.base_vendor / relative_path)
        for relative_path in base_host_libraries
    }

    discarded_host_variants: list[str] = []
    for soc, vendor_root in context.inputs[1:]:
        discarded_host_variants.extend(
            _compare_host_payload(
                context.base_common_files,
                base_host_fingerprints,
                soc,
                vendor_root,
            )
        )
    return discarded_host_variants


def _copy_vendor_payloads(context: _MergeContext) -> int:
    """Copy the selected host vendor and each additional SoC payload."""
    shutil.rmtree(context.output, ignore_errors=True)
    shutil.copytree(context.base_vendor, context.output)
    for soc, vendor_root in context.inputs[1:]:
        kernel_path, kernel_config_path, config_path = _require_soc_payload(vendor_root, soc)
        shutil.copytree(kernel_path, context.output / _KERNEL_ROOT / soc)
        shutil.copytree(kernel_config_path, context.output / _KERNEL_CONFIG_ROOT / soc)
        shutil.copytree(config_path, context.output / _CONFIG_ROOT / soc)
    return _merge_supported_ops(context.inputs, context.output)


def _require_merged_opapi(context: _MergeContext) -> Path:
    """Return the single merged operator API library."""
    libraries = sorted(context.output.rglob("libcust_opapi.so"))
    if len(libraries) != 1:
        raise ValueError(f"Merged vendor must contain one libcust_opapi.so, found {libraries}")
    return libraries[0]


def _build_merge_report(
    context: _MergeContext,
    discarded_host_variants: list[str],
    supported_ops_entries: int,
    opapi_library: Path,
) -> dict[str, Any]:
    """Build the stable machine-readable merge report."""
    return {
        "schema_version": 1,
        "status": "PASSED",
        "vendor_root": str(context.output),
        "supported_socs": [soc for soc, _ in context.inputs],
        "host_vendor_soc": context.base_soc,
        "host_payload_files": len(context.base_common_files),
        "host_input_identity": context.host_input_identity,
        "discarded_host_variants": discarded_host_variants,
        "supported_ops_entries": supported_ops_entries,
        "libcust_opapi_sha256": _sha256(opapi_library),
    }


def merge_vendors(
    inputs: list[tuple[str, Path]],
    output: Path,
    host_input_identities: dict[str, str],
) -> dict[str, Any]:
    """Retain one provenanced host vendor and merge verified per-SoC kernels.

    Args:
        inputs: Ordered SoC and vendor-root pairs.
        output: Destination directory for the merged vendor payload.
        host_input_identities: Build identities keyed by SoC name.
    """
    context = _prepare_merge(inputs, output, host_input_identities)
    discarded_host_variants = _validate_common_host_payload(context)
    supported_ops_entries = _copy_vendor_payloads(context)
    opapi_library = _require_merged_opapi(context)
    return _build_merge_report(
        context,
        discarded_host_variants,
        supported_ops_entries,
        opapi_library,
    )


def main() -> int:
    """Merge command-line inputs and optionally write a report."""
    args = _parse_args()
    inputs: list[tuple[str, Path]] = []
    for value in args.input:
        soc, separator, path = value.partition("=")
        if not separator or not soc or not path:
            raise ValueError(f"Invalid --input {value!r}; expected SOC=VENDOR_ROOT.")
        inputs.append((soc, Path(path)))
    host_input_identities: dict[str, str] = {}
    for value in args.host_input_identity:
        soc, separator, identity = value.partition("=")
        if not separator or not soc or not identity:
            raise ValueError(f"Invalid --host-input-identity {value!r}; expected SOC=SHA256.")
        if soc in host_input_identities:
            raise ValueError(f"Duplicate host input identity: {soc}")
        host_input_identities[soc] = identity
    report = merge_vendors(inputs, Path(args.output), host_input_identities)
    report_text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    print(report_text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
